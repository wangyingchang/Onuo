<template>
  <div class="order_two">
    <h1>{{ msg }}</h1>
    
    
  </div>
</template>
<script>
export default {
  name: "order_two",
  data() {
    return {
      msg: "订单录入第三步",
    };
  }
};
</script>
<style scoped>
</style>